const express = require('express');
const cors = require('cors');
const path = require('path');
const mongoose = require('mongoose');
const app = express();

// Middleware setup
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'subjects-public')));

// MongoDB connection with error handling
mongoose.connect('mongodb://localhost:27017/timetableGenerator', {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => {
    console.log('Connected to MongoDB for Exams');
}).catch(err => {
    console.error('MongoDB connection error:', err);
    process.exit(1); // Exit if cannot connect to database
});

// Define a schema for chapters
const chapterSchema = new mongoose.Schema({
    name: String,
    description: String,
    completed: { type: Boolean, default: false },
    topics: [{
        name: String,
        description: String,
        completed: { type: Boolean, default: false },
        studyTime: { type: Number, default: 0 }
    }],
    studyTime: { type: Number, default: 0 }
});

// Create a model for chapters
const Chapter = mongoose.model('Chapter', chapterSchema);

// Routes

// Get all chapters
app.get('/api/chapters', async (req, res) => {
    try {
        const chapters = await Chapter.find();
        res.json(chapters);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Add a new chapter
app.post('/api/chapters', async (req, res) => {
    const chapter = new Chapter(req.body);
    try {
        const savedChapter = await chapter.save();
        res.status(201).json(savedChapter);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Update a chapter
app.put('/api/chapters/:id', async (req, res) => {
    try {
        const updatedChapter = await Chapter.findByIdAndUpdate(req.params.id, req.body, { new: true });
        res.json(updatedChapter);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Delete a chapter
app.delete('/api/chapters/:id', async (req, res) => {
    try {
        await Chapter.findByIdAndDelete(req.params.id);
        res.json({ message: 'Chapter deleted' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});