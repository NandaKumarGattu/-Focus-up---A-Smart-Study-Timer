const express = require('express');
const cors = require('cors');
const path = require('path');
const mongoose = require('mongoose');
const app = express();

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'subjects-public')));

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/timetableGenerator', {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => {
    console.log('Connected to MongoDB for Chapters and Topics');
}).catch(err => {
    console.error('MongoDB connection error:', err);
    process.exit(1);
});

// const mongoose = require('mongoose');

// Home route
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'subjects-public', 'alarmchapter.html'));
});

// Chapter Schema
const ChapterSchema = new mongoose.Schema({
    name: { 
        type: String, 
        required: true 
    },
    description: { 
        type: String, 
        required: false 
    },
    completed: { 
        type: Boolean, 
        default: false 
    },
    topics: [{
        name: { 
            type: String, 
            required: true 
        },
        description: { 
            type: String, 
            required: false 
        },
        completed: { 
            type: Boolean, 
            default: false 
        },
        studyTime: { 
            type: Number, 
            default: 0 
        }
    }],
    createdAt: { 
        type: Date, 
        default: Date.now 
    }
});

const Chapter = mongoose.model('Chapter', ChapterSchema);

// Chapter and Topic Schemas (as defined above)

// Create a new chapter
app.post('/api/chapters', async (req, res) => {
    try {
        const { name, description } = req.body;

        if (!name) {
            return res.status(400).send({ error: 'Chapter name is required' });
        }

        const chapter = new Chapter({ name, description });
        const savedChapter = await chapter.save();
        res.status(201).send(savedChapter);
    } catch (error) {
        res.status(400).send({ error: error.message });
    }
});

// Get all chapters
app.get('/api/chapters', async (req, res) => {
    try {
        const chapters = await Chapter.find({});
        res.send(chapters);
    } catch (error) {
        res.status(500).send({ error: error.message });
    }
});

// Add a topic to a chapter
app.post('/api/chapters/:chapterId/topics', async (req, res) => {
    try {
        const { chapterId } = req.params;
        const { name, description } = req.body;

        if (!name) {
            return res.status(400).send({ error: 'Topic name is required' });
        }

        const chapter = await Chapter.findById(chapterId);
        if (!chapter) {
            return res.status(404).send({ error: 'Chapter not found' });
        }

        chapter.topics.push({ name, description });
        await chapter.save();
        res.status(201).send(chapter);
    } catch (error) {
        res.status(400).send({ error: error.message });
    }
});

// Delete a chapter
app.delete('/api/chapters/:id', async (req, res) => {
    try {
        const chapter = await Chapter.findByIdAndDelete(req.params.id);
        if (!chapter) {
            return res.status(404).send({ error: 'Chapter not found' });
        }
        res.send(chapter);
    } catch (error) {
        res.status(500).send({ error: error.message });
    }
});

// Delete a topic from a chapter
app.delete('/api/chapters/:chapterId/topics/:topicId', async (req, res) => {
    try {
        const { chapterId, topicId } = req.params;
        const chapter = await Chapter.findById(chapterId);
        if (!chapter) {
            return res.status(404).send({ error: 'Chapter not found' });
        }

        chapter.topics.id(topicId).remove();
        await chapter.save();
        res.send(chapter);
    } catch (error) {
        res.status(500).send({ error: error.message });
    }
});

// Server initialization
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Exams server running on port ${PORT}`);
});