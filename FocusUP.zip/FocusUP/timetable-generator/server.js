const express = require('express');
const cors = require('cors');
const path = require('path');
const mongoose = require('mongoose');
const app = express();

// Middleware setup
app.use(cors());
app.use(express.json());

// Serve static files from both directories
app.use(express.static(path.join(__dirname, 'subjects-public')));
app.use(express.static(path.join(__dirname, 'subject00-public')));

// MongoDB connection with error handling
mongoose.connect('mongodb://localhost:27017/timetableGenerator', {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => {
    console.log('Connected to MongoDB for Timetable Generator');
}).catch(err => {
    console.error('MongoDB connection error:', err);
    process.exit(1); // Exit if cannot connect to database
});

// Subject Schema definition
const SubjectSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    description: {
        type: String,
        required: true
    },
    iconClass: {
        type: String,
        default: 'ri-book-line'
    },
    buttonColor: {
        type: String,
        default: 'blue'
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
});

// Exam Schema definition
const ExamSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    description: {
        type: String,
        required: true
    },
    iconClass: {
        type: String,
        default: 'ri-book-line'
    },
    iconColor: {
        type: String,
        default: 'indigo-600'
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
});

// Create models
const Subject = mongoose.model('Subject', SubjectSchema);
const Exam = mongoose.model('Exam', ExamSchema);

// Route for subjects page
app.get('/subjects', (req, res) => {
    res.sendFile(path.join(__dirname, 'subjects-public', 'subjects.html'));
});

// Route for exams page
app.get('/exams', (req, res) => {
    res.sendFile(path.join(__dirname, 'subjects-public', 'exams.html'));
});

// Default route redirects to subjects
app.get('/', (req, res) => {
    res.redirect('/subjects');
});

// Debug endpoint to check routes
app.get('/api/debug', (req, res) => {
    res.json({
        message: 'API is working',
        routes: {
            subjects: '/api/subjects',
            exams: '/api/exams'
        }
    });
});

// SUBJECT ROUTES

// Create a new subject
app.post('/api/subjects', async (req, res) => {
    try {
        console.log('Received subject creation request:', req.body);
        
        const { name, description, iconClass, buttonColor } = req.body;
        
        // Validate required fields
        if (!name || !description) {
            return res.status(400).send({
                error: 'Name and description are required fields'
            });
        }
        
        const subject = new Subject({
            name,
            description,
            iconClass: iconClass || 'ri-book-line',
            buttonColor: buttonColor || 'blue'
        });
        
        console.log('Attempting to save subject:', subject);
        
        const savedSubject = await subject.save();
        console.log('Subject saved successfully:', savedSubject);
        
        res.status(201).send(savedSubject);
    } catch (error) {
        console.error('Error creating subject:', error);
        res.status(400).send({ error: error.message });
    }
});

// Get all subjects
app.get('/api/subjects', async (req, res) => {
    try {
        const subjects = await Subject.find({}).sort({ createdAt: -1 });
        console.log('Found subjects:', subjects);
        res.send(subjects);
    } catch (error) {
        console.error('Error fetching subjects:', error);
        res.status(500).send({ error: error.message });
    }
});

// Delete a subject
app.delete('/api/subjects/:id', async (req, res) => {
    try {
        const subject = await Subject.findByIdAndDelete(req.params.id);
        if (!subject) {
            return res.status(404).send({ error: 'Subject not found' });
        }
        res.send(subject);
    } catch (error) {
        res.status(500).send({ error: error.message });
    }
});

// EXAM ROUTES

// Create a new exam
app.post('/api/exams', async (req, res) => {
    try {
        console.log('Received exam creation request:', req.body);
        
        const { name, description, iconClass, iconColor } = req.body;
        
        // Validate required fields
        if (!name || !description) {
            return res.status(400).send({
                error: 'Name and description are required fields'
            });
        }
        
        const exam = new Exam({
            name,
            description,
            iconClass: iconClass || 'ri-book-line',
            iconColor: iconColor || 'indigo-600'
        });
        
        console.log('Attempting to save exam:', exam);
        
        const savedExam = await exam.save();
        console.log('Exam saved successfully:', savedExam);
        
        res.status(201).send(savedExam);
    } catch (error) {
        console.error('Error creating exam:', error);
        res.status(400).send({ error: error.message });
    }
});

// Get all exams
app.get('/api/exams', async (req, res) => {
    try {
        const exams = await Exam.find({}).sort({ createdAt: -1 });
        console.log('Found exams:', exams);
        res.send(exams);
    } catch (error) {
        console.error('Error fetching exams:', error);
        res.status(500).send({ error: error.message });
    }
});

// Delete an exam
app.delete('/api/exams/:id', async (req, res) => {
    try {
        const exam = await Exam.findByIdAndDelete(req.params.id);
        if (!exam) {
            return res.status(404).send({ error: 'Exam not found' });
        }
        res.send(exam);
    } catch (error) {
        res.status(500).send({ error: error.message });
    }
});

// Server initialization
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Combined server running on port ${PORT}`);
    console.log(`Access subjects at: http://localhost:${PORT}/subjects`);
    console.log(`Access exams at: http://localhost:${PORT}/exams`);
});