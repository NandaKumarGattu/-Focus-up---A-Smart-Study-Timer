// Backend for Timetable Generator
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const path = require('path');
const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// MongoDB Connection
mongoose.connect('mongodb://localhost:27017/timetableGenerator', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    // useCreateIndex: true
}).then(() => {
    console.log('Connected to MongoDB');
}).catch(err => {
    console.error('MongoDB connection error:', err);
});

// User Schema
const UserSchema = new mongoose.Schema({
    username: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    createdAt: { type: Date, default: Date.now }
});

// Timetable Schema
const TimetableSchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    name: { type: String, required: true },
    subjects: [{
        name: { type: String, required: true },
        level: { type: String, enum: ['basic', 'intermediate', 'advanced'], required: true },
        hours: { type: Number, required: true, min: 1, max: 5 }
    }],
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now }
});

// // Models
// const User = mongoose.model('User', UserSchema);
// const Timetable = mongoose.model('Timetable', TimetableSchema);

// Hash password before saving
UserSchema.pre('save', async function(next) {
    if (this.isModified('password')) {
        this.password = await bcrypt.hash(this.password, 10);
    }
    next();
});

// Models
const User = mongoose.model('User', UserSchema);
const Timetable = mongoose.model('Timetable', TimetableSchema);

// Helper function to generate JWT token
const generateToken = (user) => {
    return jwt.sign(
        { id: user._id, username: user.username },
        process.env.JWT_SECRET || 'your_jwt_secret',
        { expiresIn: '1d' }
    );
};

// Middleware for authentication
const auth = async (req, res, next) => {
    try {
        const token = req.header('Authorization').replace('Bearer ', '');
        const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your_jwt_secret');
        const user = await User.findById(decoded.id);
        
        if (!user) {
            throw new Error();
        }
        
        req.user = user;
        next();
    } catch (error) {
        res.status(401).send({ error: 'Please authenticate.' });
    }
};

// Routes

// Register user    
app.post('/api/users/register', async (req, res) => {
    try {
        const { username, email, password } = req.body;
        const user = new User({ username, email, password });
        await user.save();
        const token = generateToken(user);
        res.status(201).send({ user: { id: user._id, username, email }, token });
    } catch (error) {
        if (error.code === 11000) {
            return res.status(400).send({ error: 'Username or email already exists' });
        }
        res.status(400).send({ error: error.message });
    }
});

// Login user
app.post('/api/users/login', async (req, res) => {
    try {
        const { username, password } = req.body;
        const user = await User.findOne({ username });
        
        if (!user) {
            return res.status(400).send({ error: 'Invalid login credentials' });
        }
        
        const isMatch = await bcrypt.compare(password, user.password);
        
        if (!isMatch) {
            return res.status(400).send({ error: 'Invalid login credentials' });
        }
        
        const token = generateToken(user);
        res.send({ user: { id: user._id, username, email: user.email }, token });
    } catch (error) {
        res.status(400).send({ error: error.message });
    }
});

// Save timetable
app.post('/api/timetables', auth, async (req, res) => {
    try {
        const { name, subjects } = req.body;
        const timetable = new Timetable({
            userId: req.user._id,
            name,
            subjects
        });
        await timetable.save();
        res.status(201).send(timetable);
    } catch (error) {
        res.status(400).send({ error: error.message });
    }
});

// Get user's timetables
app.get('/api/timetables', auth, async (req, res) => {
    try {
        const timetables = await Timetable.find({ userId: req.user._id }).sort({ updatedAt: -1 });
        res.send(timetables);
    } catch (error) {
        res.status(500).send({ error: error.message });
    }
});

// Get specific timetable
app.get('/api/timetables/:id', auth, async (req, res) => {
    try {
        const timetable = await Timetable.findOne({ _id: req.params.id, userId: req.user._id });
        
        if (!timetable) {
            return res.status(404).send({ error: 'Timetable not found' });
        }
        
        res.send(timetable);
    } catch (error) {
        res.status(500).send({ error: error.message });
    }
});

// Update timetable
app.patch('/api/timetables/:id', auth, async (req, res) => {
    try {
        const updates = Object.keys(req.body);
        const allowedUpdates = ['name', 'subjects'];
        const isValidOperation = updates.every(update => allowedUpdates.includes(update));
        
        if (!isValidOperation) {
            return res.status(400).send({ error: 'Invalid updates!' });
        }
        
        const timetable = await Timetable.findOne({ _id: req.params.id, userId: req.user._id });
        
        if (!timetable) {
            return res.status(404).send({ error: 'Timetable not found' });
        }
        
        updates.forEach(update => timetable[update] = req.body[update]);
        timetable.updatedAt = Date.now();
        await timetable.save();
        res.send(timetable);
    } catch (error) {
        res.status(400).send({ error: error.message });
    }
});

// Delete timetable
app.delete('/api/timetables/:id', auth, async (req, res) => {
    try {
        const timetable = await Timetable.findOneAndDelete({ _id: req.params.id, userId: req.user._id });
        
        if (!timetable) {
            return res.status(404).send({ error: 'Timetable not found' });
        }
        
        res.send(timetable);
    } catch (error) {
        res.status(500).send({ error: error.message });
    }
});

// Serve the frontend
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start server
const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});

// Backend: subject.model.js
// const mongoose = require('mongoose');

const SubjectSchema = new mongoose.Schema({
    name: { 
        type: String, 
        required: true,
        unique: true 
    },
    description: { 
        type: String, 
        required: true 
    },
    iconClass: { 
        type: String, 
        default: 'ri-book-line' 
    },
    buttonColor: { 
        type: String, 
        default: 'blue' 
    },
    createdAt: { 
        type: Date, 
        default: Date.now 
    },
    userId: { 
        type: mongoose.Schema.Types.ObjectId, 
        ref: 'User',
        required: true
    }
});

const Subject = mongoose.model('Subject', SubjectSchema);

// Backend: Add these routes to your existing Express app
app.post('/api/subjects', auth, async (req, res) => {
    try {
        const { name, description, iconClass, buttonColor } = req.body;
        const subject = new Subject({
            name,
            description,
            iconClass,
            buttonColor,
            userId: req.user._id
        });
        await subject.save();
        res.status(201).send(subject);
    } catch (error) {
        if (error.code === 11000) {
            return res.status(400).send({ error: 'Subject already exists' });
        }
        res.status(400).send({ error: error.message });
    }
});

app.get('/api/subjects', auth, async (req, res) => {
    try {
        const subjects = await Subject.find({ userId: req.user._id });
        res.send(subjects);
    } catch (error) {
        res.status(500).send({ error: error.message });
    }
});

app.delete('/api/subjects/:id', auth, async (req, res) => {
    try {
        const subject = await Subject.findOneAndDelete({
            _id: req.params.id,
            userId: req.user._id
        });
        if (!subject) {
            return res.status(404).send({ error: 'Subject not found' });
        }
        res.send(subject);
    } catch (error) {
        res.status(500).send({ error: error.message });
    }
});



